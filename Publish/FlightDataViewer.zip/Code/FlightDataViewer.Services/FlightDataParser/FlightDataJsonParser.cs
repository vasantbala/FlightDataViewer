﻿using FlightDataViewer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightDataViewer.Services.FlightDataParser
{
    /// <summary>
    /// Json Parser
    /// </summary>
    public class FlightDataJsonParser : IFlightDataParser
    {
        public FlightTransit[] Parse(FlightDataSource dataSource)
        {
            throw new NotImplementedException();
        }
    }
}
